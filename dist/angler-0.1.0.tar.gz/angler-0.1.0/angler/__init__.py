"""
Angler
~~~~~~~~~~
The hook to catch your FISH data.
:author: Omid Gholamalamdari
:license: BSD
"""
import logging
__version__ = '0.1.0'
from .io import *
from .oligo_lib_functions import *
from .angler_general import *
